# Shortwave MPRIS v5.1.0 - Binary Release

This release contains a prebuilt binary of Shortwave with extended MPRIS support, DLNA/UPnP, and Google Cast device support.

## Contents

- `shortwave-mpris_5.1.0_linux-amd64` - Main executable binary (x86_64)
- `de.haeckerfelix.Shortwave.desktop` - Desktop entry file
- `de.haeckerfelix.Shortwave.gschema.xml` - GSettings schema
- `de.haeckerfelix.Shortwave.metainfo.xml` - AppStream metadata
- `de.haeckerfelix.Shortwave.service` - D-Bus service file
- `de.haeckerfelix.Shortwave.gresource` - Application resources
- `de.haeckerfelix.Shortwave.svg` - Application icon
- `de.haeckerfelix.Shortwave-symbolic.svg` - Symbolic icon
- `SHA256SUMS` - Checksums for all files

## Installation

### Manual Installation

```bash
# Install binary
sudo install -Dm755 shortwave-mpris_5.1.0_linux-amd64 /usr/bin/shortwave

# Install desktop file
sudo install -Dm644 de.haeckerfelix.Shortwave.desktop /usr/share/applications/de.haeckerfelix.Shortwave.desktop

# Install GSettings schema
sudo install -Dm644 de.haeckerfelix.Shortwave.gschema.xml /usr/share/glib-2.0/schemas/de.haeckerfelix.Shortwave.gschema.xml
sudo glib-compile-schemas /usr/share/glib-2.0/schemas/

# Install metainfo
sudo install -Dm644 de.haeckerfelix.Shortwave.metainfo.xml /usr/share/metainfo/de.haeckerfelix.Shortwave.metainfo.xml

# Install D-Bus service
sudo install -Dm644 de.haeckerfelix.Shortwave.service /usr/share/dbus-1/services/de.haeckerfelix.Shortwave.service

# Install gresource
sudo install -Dm644 de.haeckerfelix.Shortwave.gresource /usr/share/shortwave/de.haeckerfelix.Shortwave.gresource

# Install icons
sudo install -Dm644 de.haeckerfelix.Shortwave.svg /usr/share/icons/hicolor/scalable/apps/de.haeckerfelix.Shortwave.svg
sudo install -Dm644 de.haeckerfelix.Shortwave-symbolic.svg /usr/share/icons/hicolor/symbolic/apps/de.haeckerfelix.Shortwave-symbolic.svg
sudo gtk-update-icon-cache -q -t -f /usr/share/icons/hicolor

# Update desktop database
sudo update-desktop-database -q
```

### Arch Linux (AUR)

Install via AUR package: `shortwave-mpris-bin`

```bash
yay -S shortwave-mpris-bin
```

## Dependencies

- gtk4 >= 4.18.0
- libadwaita >= 1.8.0
- libshumate >= 1.3.0
- gstreamer >= 1.24.0
- gst-plugins-base-libs >= 1.24.0
- gst-plugins-bad >= 1.24.0
- gst-plugins-good
- gst-libav
- ffmpeg >= 4.0.0
- sqlite >= 3.20.0
- openssl >= 1.0.0
- dbus
- glib2 >= 2.80.0
- glycin-gtk4 >= 2.0.0
- lcms2 >= 2.12.0
- libseccomp >= 2.5.0

## Verification

Verify checksums:
```bash
sha256sum -c SHA256SUMS
```

## License

GPL-3.0-or-later (see COPYING.md)
